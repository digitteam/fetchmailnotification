To configure this module, you need to:

#. Configure your fetchmail server setting 'Error notice template' = 'Fetchmail - error notice'.
#. You can edit the 'Fetchmail - error notice' email template according to your needs.
